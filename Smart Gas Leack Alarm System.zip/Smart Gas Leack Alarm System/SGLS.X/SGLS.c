//Library Files
#include <xc.h>
#define _XTAL_FREQ 20000000

// CONFIG
#pragma config FOSC = HS     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = ON         // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3/PGM pin has PGM function; low-voltage programming enabled)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

#define RS PORTBbits.RB0 //Rename RC0 as RS
#define RW PORTBbits.RB1 //Rename RC0 as RS
#define EN PORTBbits.RB2 //Rename RC0 as RS

void lcd_data(unsigned char data)
{
    PORTB = (data & 0xF0);
    EN = 1; //Enable Clock
    RW = 0; //low
    RS = 1; //High
    __delay_ms(10);
    EN = 0; //Off Clock
    PORTB = ((data<<4) & 0xF0);
    EN = 1; //Enable Clock
    RW = 0; //low
    RS = 1; //High
    __delay_ms(10);
    EN = 0; //Off Clock
}

void lcd_command(unsigned char cmd)
{
    PORTB = (cmd & 0xF0);
    EN = 1; //Enable clock
    RW = 0; //Low RW
    RS = 0; //Low RS
    __delay_ms(10);
    EN = 0; //off clock 
    PORTB = ((cmd<<4) & 0xF0);
    EN = 1; //Enable clock
    RW = 0; //Low RW
    RS = 0; //Low RS
    __delay_ms(10);
    EN = 0; //off clock 
}

void lcd_string(unsigned char *str,int num) //Function For String input
{
    int i;
    for(i=0; i<num; i++)
    {
        lcd_data(str[i]);
    }
}

void lcd_initialise() //initialise input data command for LCD
{
    lcd_command(0x02); //16x2 display
    lcd_command(0x28); //move the cursor
    lcd_command(0x0C); //LCD on cursor off
    lcd_command(0x06);
    lcd_command(0x01); //LCD clean
}

//Variables
unsigned int GAS_Value; //16 bit Variable because Unsigned.
unsigned int a,b,c,d,e,f,g; //For Printing Process

//Main Code
void main(void)
{
    //I/O Configuration
    TRISB = 0x00;
    TRISC = 0x00;
    PORTCbits.RC0 = 0;
    PORTCbits.RC1 = 0;
    
    //Initialise
    lcd_initialise();
    
    //ADC ON 0 And 1 FOSC/8
    ADCON0bits.ADCS0=1;
    ADCON0bits.ADCS1=0;
    ADCON1bits.ADCS2=0;
    
    //Power On ADCON
    ADCON0bits.ADON=1;
    
    //ADC Port Configuration
    ADCON1bits.PCFG0=0;
    ADCON1bits.PCFG1=1;
    ADCON1bits.PCFG2=1;
    ADCON1bits.PCFG3=1;
    
    //ADCON Result Format
    ADCON1bits.ADFM=1;
    
    //Greetings 
    lcd_command(0x80);
    lcd_string("WELCOME",7);
    
    //Loop Function
    while(1)
    {
        //Print Line 01
        
        //Reading Format Of ADC
        ADCON0bits.CHS0=0;
        ADCON0bits.CHS1=0;
        ADCON0bits.CHS2=0;
        
        //Start ADC conversion
        ADCON0bits.GO_DONE=1;
        
        //Check State Of ADC Conversion
        while(PIR1bits.ADIF==0);
        
        //Store The Value
        GAS_Value = ADRESH<<8;
        GAS_Value = GAS_Value + ADRESL;
        
        //Print The Value REG_Value = 1023 (Max)
        if(GAS_Value < 700)
        {
            lcd_command(0x80);
            lcd_string("DANGER",6);
            lcd_command(0xC0);
            lcd_string("BUTANE GAS LEAK ",16);
            PORTCbits.RC0 = 1;
            PORTCbits.RC1 = 1;
        }
        else if(GAS_Value < 800)
        {
            lcd_command(0x80);
            lcd_string("DANGER",6);
            lcd_command(0xC0);
            lcd_string("METHANE GAS LEAK",16);
            PORTCbits.RC0 = 1;
            PORTCbits.RC1 = 1;
        }
        else if(GAS_Value < 1000)
        {
            lcd_command(0x80);
            lcd_string("DANGER",6);
            lcd_command(0xC0);
            lcd_string("LPG GAS LEAK    ",16);
            PORTCbits.RC0 = 1;
            PORTCbits.RC1 = 1;
        }
        else
        {
            lcd_command(0x80);
            lcd_string("NO LEAK FOUND   ",16);
            lcd_command(0xC0);
            lcd_string("YOU ARE SAFE NOW",16);
            PORTCbits.RC0 = 0;
            PORTCbits.RC1 = 0;
        }
    }
    return;
}
